package testing;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class MyTests {

	private WebDriver driver;
	private JavascriptExecutor jse;
	private WebDriverWait wait;
	private String baseUrl = "http://trivago.in";
	private String destination;
	private String checkInDate;
	private String checkOutDate;
	private int adults;
	private int children;
	private int rooms;
	private List<String> hotelsLocation = new LinkedList<String>();
	private List<Float> hotelsRating = new LinkedList<Float>();
	private String successMessage;
	private String failureMessage;

	@SuppressWarnings("deprecation")
	@BeforeTest
	@Parameters("browser")
	public void createDriver(@Optional("chrome") String browser) {
		System.out.println("==============================");
		System.out.println("Automation and Testing in " + browser + ":\n");

		if (browser.equalsIgnoreCase("edge"))
			driver = new EdgeDriver();
		else if (browser.equalsIgnoreCase("chrome"))
			driver = new ChromeDriver();

		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		jse = (JavascriptExecutor) driver;
	}

	@AfterTest
	public void tearDown() {
		System.out.println("Closing the browser.");
		driver.quit();
	}

	@Test(
		testName = "Search Criteria Automation",
		description = "Automating the search criteria."
	)
	public void automation() {

		successMessage = "Automation Completed.";
		failureMessage = "Automation Incomplete.";

		// Reading data from file using ApachePOI
		readExcelFile();

		// Selecting destination location
		selectDestination();

		// Selecting check-in date
		selectDate(checkInDate);

		// Selecting check-out date
		selectDate(checkOutDate);

		// Selecting guests and rooms
		selectGuestsAndRooms(adults, children, rooms);

		// Clicking search button
		driver.findElement(By.cssSelector("button[data-testid = 'search-button-with-loader']")).click();

		// Sorting based on given condition
		sortResultsBasedOnCondition();

		// Fetching hotel details
		fetchingHotelDetails();

		System.out.println("-----------------------------");

	}

	@Test(
		testName = "Sorted Order(Descending) Test Case", 
		description = "Verify if all the hotels rating are in descending order.",
		dependsOnMethods = "automation"
	)
	public void sortedOrderTestCase() {
		successMessage = "Hotels rating are in descending order";
		failureMessage = "Hotels rating are not in descending order";
		for (int i = 1; i < hotelsRating.size(); i++)
			Assert.assertTrue(hotelsRating.get(i - 1) > hotelsRating.get(i));
	}

	@Test(
		testName = "Hotels Location Test Case", 
		description = "Verify if first 5 hotels are from the given location",
		dependsOnMethods = "automation"
	)
	public void hotelLocationTestCase() {
		successMessage = "First 5 hotels are from " + destination;
		failureMessage = "First 5 hotels are not from " + destination;
		for (int i = 0; i < 5; i++)
			Assert.assertEquals(hotelsLocation.get(i), destination);
	}

	@AfterMethod
	public void getTestsResult(ITestResult result) {

		System.out.println("Running " + result.getName());
		System.out.println("Description: " + result.getMethod().getDescription());

		switch (result.getStatus()) {
		case ITestResult.SUCCESS:
			System.out.println("Outcome: " + successMessage);
			System.out.println("Result: PASSED");
			break;
		case ITestResult.FAILURE:
			System.out.println("Outcome: " + failureMessage);
			System.out.println("Result: FAILED");
			break;
		default:
			System.out.println("Invalid test status.");
		}
		System.out.println();
	}

	private void readExcelFile() {

		try {
			String relativePath = "/test-data/data.xlsx";
			String currDir = System.getProperty("user.dir");
			FileInputStream file = new FileInputStream(new File(currDir, relativePath));
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheetAt(0);

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd MMMM yyyy");

			Iterator<Row> rowItertor = sheet.iterator();

			boolean isFirstRow = true;
			while (rowItertor.hasNext()) {
				if (isFirstRow) {
					isFirstRow = false;
					continue;
				}
				Row row = rowItertor.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();

					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						destination = cell.getStringCellValue();
						break;

					case Cell.CELL_TYPE_NUMERIC:
						if (DateUtil.isCellDateFormatted(cell)) {
							LocalDate date = cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault())
									.toLocalDate();
							if (cell.getColumnIndex() == 1)
								checkInDate = dtf.format(date);
							if (cell.getColumnIndex() == 2)
								checkOutDate = dtf.format(date);
						} else {
							if (cell.getColumnIndex() == 3)
								adults = (int) cell.getNumericCellValue();
							if (cell.getColumnIndex() == 4)
								children = (int) cell.getNumericCellValue();
							if (cell.getColumnIndex() == 5)
								rooms = (int) cell.getNumericCellValue();
						}
						break;
					}
				}
			}

			workbook.close();
			file.close();

		} catch (IOException e) {
			// System.out.println("Error reading from file: " + e.getMessage());
		}

	}

	private void selectDestination() {
		for (int attempt = 0; attempt < 3; attempt++) {
			try {
				WebElement searchBox = driver.findElement(By.name("query"));
				searchBox.sendKeys(destination);
				WebElement firstOption = driver.findElement(By.cssSelector("li[role = 'option']"));
				jse.executeScript("arguments[0].click()", firstOption);
				return;
			} catch (Exception e) {
				// System.out.println("\nSelect Destination:");
				// System.out.println("Error selecting destination, retrying... ");
			}
		}
	}

	private void selectDate(String date) {
		String[] expDate = date.split(" ");
		int expDay = Integer.parseInt(expDate[0]);
		String expMonth = expDate[1];
		String expYear = expDate[2];

		while (true) {
			String[] monthYear = driver.findElement(By.cssSelector("div.text-center:first-child h3")).getText()
					.split(" ");
			if (expMonth.equals(monthYear[0]) && expYear.equals(monthYear[1]))
				break;
			WebElement nxtButton = driver.findElement(By.cssSelector("button[aria-label = 'next']"));
			jse.executeScript("arguments[0].click()", nxtButton);
		}

		for (int attempt = 0; attempt < 3; attempt++) {
			try {
				List<WebElement> dates = driver.findElements(By
						.cssSelector("div.text-center:first-child div:nth-child(3) button:not([class*= 'invisible'])"));
				for (WebElement ele : dates) {
					int currDate = Integer.parseInt(ele.getText());
					if (currDate == expDay) {
						jse.executeScript("arguments[0].click()", ele);
						break;
					}
				}
			} catch (StaleElementReferenceException se) {
				// System.out.println("\nSelect Date:\nStale element reference exception
				// occurred, retrying...");
			} catch (ElementClickInterceptedException ce) {
				// System.out.println("\nSelect Date:\nClick intercepted exception occured,
				// retrying...");
			}
		}
	}

	private void selectGuestsAndRooms(int expAdults, int expChildren, int expRooms) {
		while (true) {
			int actAdults = Integer.parseInt(
					driver.findElement(By.cssSelector("input[data-testid = 'adults-amount']")).getAttribute("value"));
			if (expAdults == actAdults)
				break;
			else if (expAdults > actAdults) {
				WebElement plusBtn = driver
						.findElement(By.cssSelector("button[data-testid = 'adults-amount-plus-button']"));
				jse.executeScript("arguments[0].clcik()", plusBtn);
			} else {
				WebElement minusBtn = driver
						.findElement(By.cssSelector("button[data-testid = 'adults-amount-minus-button']"));
				jse.executeScript("arguments[0].click()", minusBtn);
			}
		}
		while (true) {
			int actChildren = Integer.parseInt(
					driver.findElement(By.cssSelector("input[data-testid = 'children-amount']")).getAttribute("value"));
			if (expChildren == actChildren)
				break;
			else if (expChildren > actChildren) {
				WebElement plusBtn = driver
						.findElement(By.cssSelector("button[data-testid = 'children-amount-plus-button']"));
				jse.executeScript("arguments[0].clcik()", plusBtn);
			} else {
				WebElement minusBtn = driver
						.findElement(By.cssSelector("button[data-testid = 'children-amount-minus-button']"));
				jse.executeScript("arguments[0].click()", minusBtn);
			}
		}
		while (true) {
			int actRooms = Integer.parseInt(
					driver.findElement(By.cssSelector("input[data-testid = 'rooms-amount']")).getAttribute("value"));
			if (expRooms == actRooms)
				break;
			else if (expRooms > actRooms) {
				WebElement plusBtn = driver
						.findElement(By.cssSelector("button[data-testid = 'rooms-amount-plus-button']"));
				jse.executeScript("arguments[0].clcik()", plusBtn);
			} else {
				WebElement minusBtn = driver
						.findElement(By.cssSelector("button[data-testid = 'rooms-amount-minus-button']"));
				jse.executeScript("arguments[0].click()", minusBtn);
			}
		}

		driver.findElement(By.cssSelector("button[data-testid = 'guest-selector-apply']")).click();
	}

	private void sortResultsBasedOnCondition() {

		wait.until(ExpectedConditions.invisibilityOfElementLocated(
				By.cssSelector("div[class = 'LoadingAnimation_advertiserLogos__n2YTi']")));

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("label[for = 'sorting-selector']")));

		WebElement sortingElement = driver.findElement(By.id("sorting-selector"));
		Select sortSelect = new Select(sortingElement);
		sortSelect.selectByVisibleText("Rating only");
	}

	private void fetchingHotelDetails() {

		for (int attempt = 0; attempt < 3; attempt++) {
			try {
				List<WebElement> resultElements = wait.until(ExpectedConditions.visibilityOfAllElements(
						driver.findElements(By.cssSelector("li[data-testid = 'accommodation-list-element']"))));
				String location = "Not Available";
				float rating = 0.0f;
				for (int i = 0; i < resultElements.size(); i++) {
					WebElement infoExpand = resultElements.get(i)
							.findElement(By.cssSelector("button[data-testid = 'distance-label-section']"));
					jse.executeScript("arguments[0].click()", infoExpand);

					try {
						location = resultElements.get(i)
								.findElement(By.cssSelector("span[itemprop = 'addressLocaspanty']")).getText();
						rating = Float.parseFloat(resultElements.get(i)
								.findElement(By.cssSelector("span[itemprop = 'ratingValue']")).getText());
					} catch (Exception e) {

					}
					location = location.replaceAll("[^a-zA-Z]", "");

					hotelsLocation.add(location);
					hotelsRating.add(rating);
				}
				return;

			} catch (StaleElementReferenceException e) {
				// System.out.println("\nFetching Hotel Info:\nStale element reference exception
				// occurred, retrying...");
			}
		}
	}
}
